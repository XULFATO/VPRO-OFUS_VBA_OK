Attribute VB_Name = "mod_Types"
Option Explicit

Public Type Segmento
    contenido As String
    EsCodigo  As Boolean
End Type
