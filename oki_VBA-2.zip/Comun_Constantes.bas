Attribute VB_Name = "Comun_Constantes"
Option Explicit

Public HOJA_HOME As String
Public HOJA_ESP  As String
