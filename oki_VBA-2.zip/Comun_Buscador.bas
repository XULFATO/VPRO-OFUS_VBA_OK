Attribute VB_Name = "Comun_Buscador"
Option Explicit

' f_tr vive en mod_Traductor (desarrollo) y en OtAflUx01415 (produccion).
' No se declara aqui para evitar duplicados.
