Attribute VB_Name = "mod_Collector"
Option Explicit

' ============================================================================
' LLENAR DICCIONARIO
' Captura modulos, Subs, Functions y Properties del libro a ofuscar.
' Transformacion: Invertir -> Leet (a=4,e=3,i=1,o=0,s=5) -> minusculas
' Ejemplo: ContarNotas -> satoNratnoC -> 54t0Nr4tn0C -> 54t0nr4tn0c
' ============================================================================
Public Sub LlenarDiccionario(ByRef wb As Workbook, ByRef dict As Object)
    Dim vbc      As Object
    Dim i        As Long
    Dim linea    As String
    Dim nombreCapturado As String
    Dim nLineas  As Long
    
    For Each vbc In wb.VBProject.VBComponents
        If vbc.Type <= 3 Then
            
            ' 1. Nombre del modulo
            If Not EsModuloProtegido(vbc.Name) Then
                If Not dict.Exists(vbc.Name) Then
                    dict.Add vbc.Name, TransformarNombre(vbc.Name)
                End If
            End If
            
            ' 2. Nombres de Sub / Function / Property
            On Error Resume Next
            nLineas = vbc.CodeModule.CountOfLines
            On Error GoTo 0
            
            If nLineas > 0 Then
                For i = 1 To nLineas
                    On Error Resume Next
                    linea = vbc.CodeModule.Lines(i, 1)
                    On Error GoTo 0
                    linea = Trim(linea)
                    nombreCapturado = ExtraerNombreDeLinea(linea)
                    If nombreCapturado <> "" Then
                        If Not EsFuncionProtegida(nombreCapturado) Then
                            If Not dict.Exists(nombreCapturado) Then
                                dict.Add nombreCapturado, TransformarNombre(nombreCapturado)
                            End If
                        End If
                    End If
                Next i
            End If
            
        End If
    Next vbc
End Sub

' ============================================================================
' TRANSFORMAR NOMBRE: Invertir -> Leet -> Minusculas
' ============================================================================
Public Function TransformarNombre(ByVal nombre As String) As String
    Dim i As Long, resultado As String
    
    ' Paso 1: Invertir
    resultado = ""
    For i = Len(nombre) To 1 Step -1
        resultado = resultado & Mid(nombre, i, 1)
    Next i
    
    ' Paso 2: Leet speak
    resultado = Replace(resultado, "a", "4")
    resultado = Replace(resultado, "A", "4")
    resultado = Replace(resultado, "e", "3")
    resultado = Replace(resultado, "E", "3")
    resultado = Replace(resultado, "i", "1")
    resultado = Replace(resultado, "I", "1")
    resultado = Replace(resultado, "o", "0")
    resultado = Replace(resultado, "O", "0")
    resultado = Replace(resultado, "s", "5")
    resultado = Replace(resultado, "S", "5")
    
    ' Paso 3: Minusculas
    resultado = LCase(resultado)
    
    ' Seguridad: VBA no permite nombres que empiecen por digito
    If resultado <> "" Then
        If resultado Like "[0-9]*" Then resultado = "x" & resultado
    End If
    
    TransformarNombre = resultado
End Function

' ============================================================================
' EXTRAER NOMBRE DE LINEA (Sub / Function / Property Get|Let|Set)
' Filtra elementos vacios del Split para manejar indentacion y tabs
' ============================================================================
Private Function ExtraerNombreDeLinea(ByVal l As String) As String
    Dim partes()  As String
    Dim limpias() As String
    Dim i         As Integer
    Dim p         As String
    Dim nom       As String
    Dim nLimpias  As Integer
    
    ' Quitar parentesis
    l = Replace(Replace(l, "(", " "), ")", " ")
    ' Reemplazar tabs por espacio
    l = Replace(l, Chr(9), " ")
    partes = Split(l, " ")
    
    ' Filtrar elementos vacios
    nLimpias = 0
    ReDim limpias(UBound(partes))
    For i = LBound(partes) To UBound(partes)
        If Trim(partes(i)) <> "" Then
            limpias(nLimpias) = Trim(partes(i))
            nLimpias = nLimpias + 1
        End If
    Next i
    
    If nLimpias < 2 Then
        ExtraerNombreDeLinea = ""
        Exit Function
    End If
    
    For i = 0 To nLimpias - 2
        p = LCase(limpias(i))
        
        If p = "sub" Or p = "function" Then
            nom = limpias(i + 1)
            If nom <> "" And Not EsPalabraReservada(nom) Then
                ExtraerNombreDeLinea = nom
                Exit Function
            End If
        End If
        
        ' Property Get/Let/Set: nombre dos posiciones despues
        If p = "property" And i + 2 <= nLimpias - 1 Then
            nom = limpias(i + 2)
            If nom <> "" And Not EsPalabraReservada(nom) Then
                ExtraerNombreDeLinea = nom
                Exit Function
            End If
        End If
    Next i
    
    ExtraerNombreDeLinea = ""
End Function

' ============================================================================
' PROTECCIONES
' ============================================================================
Private Function EsModuloProtegido(ByVal nombre As String) As Boolean
    Dim protegidos As Variant
    protegidos = Array("mod_Main", "mod_Collector", "mod_Tokenizer", _
                       "mod_Garbage", "mod_Types", "mod_Traductor", _
                       "OtAflUx01415", "Comun_Constantes", _
                       "Comun_Buscador", "ThisWorkbook")
    Dim i As Long
    For i = LBound(protegidos) To UBound(protegidos)
        If LCase(nombre) = LCase(protegidos(i)) Then
            EsModuloProtegido = True
            Exit Function
        End If
    Next i
    EsModuloProtegido = False
End Function

Private Function EsFuncionProtegida(ByVal nombre As String) As Boolean
    Dim protegidas As Variant
    protegidas = Array( _
        "f_tr", _
        "ProcesarLineaMaestra", _
        "LlenarDiccionario", _
        "TransformarNombre", _
        "ExtraerNombreDeLinea", _
        "EjecutarOfuscador", _
        "SincronizarBotones", _
        "InyectarModuloTraductor", _
        "GenerarClaveAleatoria", _
        "ExtraerNombreMacro", _
        "InyectarRuido", _
        "GenerarBloqueRuido", _
        "GenerarComentario", _
        "NombreOpaco", _
        "CifrarTextoXOR", _
        "ReemplazarPalabraExacta", _
        "EsModuloProtegido", _
        "EsFuncionProtegida", _
        "EsPalabraReservada", _
        "Auto_Open", _
        "Workbook_Open")
    Dim i As Long
    For i = LBound(protegidas) To UBound(protegidas)
        If LCase(nombre) = LCase(protegidas(i)) Then
            EsFuncionProtegida = True
            Exit Function
        End If
    Next i
    EsFuncionProtegida = False
End Function

Private Function EsPalabraReservada(ByVal palabra As String) As Boolean
    Dim reservadas As String
    reservadas = ",get,let,set,property,byval,byref,optional,paramarray," & _
                 "as,new,withevents,friend,private,public,static,"
    EsPalabraReservada = InStr(1, reservadas, "," & LCase(palabra) & ",", vbTextCompare) > 0
End Function
